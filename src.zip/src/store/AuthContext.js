// ─────────────────────────────────────────────────────────────
//  AuthContext.js  –  Global auth state + session state
// ─────────────────────────────────────────────────────────────
import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { clearTokens, saveTokens } from '../services/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);       // UserInfo from backend
  const [isLoading, setIsLoading] = useState(true);
  const [session, setSession] = useState(null); // active shopping session
  const [cart, setCart] = useState(null);       // current CartDto

  // Restore session on app start
  useEffect(() => {
    (async () => {
      const token = await AsyncStorage.getItem('accessToken');
      const savedUser = await AsyncStorage.getItem('userInfo');
      const savedSession = await AsyncStorage.getItem('activeSession');
      if (token && savedUser) {
        setUser(JSON.parse(savedUser));
        if (savedSession) setSession(JSON.parse(savedSession));
      }
      setIsLoading(false);
    })();
  }, []);

  const login = async (tokens, userInfo) => {
    await saveTokens(tokens.accessToken, tokens.refreshToken);
    await AsyncStorage.setItem('userInfo', JSON.stringify(userInfo));
    setUser(userInfo);
  };

  const logoutUser = async () => {
    await clearTokens();
    await AsyncStorage.multiRemove(['userInfo', 'activeSession']);
    setUser(null);
    setSession(null);
    setCart(null);
  };

  const saveSession = async (sessionData) => {
    setSession(sessionData);
    await AsyncStorage.setItem('activeSession', JSON.stringify(sessionData));
  };

  const clearSession = async () => {
    setSession(null);
    setCart(null);
    await AsyncStorage.removeItem('activeSession');
  };

  return (
    <AuthContext.Provider value={{
      user, isLoading,
      session, cart,
      login, logoutUser,
      saveSession, clearSession,
      setCart,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
