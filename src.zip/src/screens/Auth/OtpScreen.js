// ─────────────────────────────────────────────────────────────
//  OtpScreen.js  –  OTP entry + auto-verify
// ─────────────────────────────────────────────────────────────
import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  ActivityIndicator, Alert, KeyboardAvoidingView, Platform,
} from 'react-native';
import { verifyOtp, resendOtp } from '../../services/api';
import { useAuth } from '../../store/AuthContext';

export default function OtpScreen({ navigation, route }) {
  const { phone, expirySeconds = 120 } = route.params;
  const { login } = useAuth();

  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [resending, setResending] = useState(false);
  const [timer, setTimer] = useState(expirySeconds);

  const inputRefs = useRef([]);

  // Countdown timer
  useEffect(() => {
    const interval = setInterval(() => {
      setTimer(t => (t > 0 ? t - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleChange = (val, idx) => {
    if (!/^\d?$/.test(val)) return;
    const next = [...otp];
    next[idx] = val;
    setOtp(next);
    if (val && idx < 5) inputRefs.current[idx + 1]?.focus();
    // Auto-submit when all 6 digits entered
    if (val && idx === 5) {
      const full = [...next.slice(0, 5), val].join('');
      if (full.length === 6) verify(full);
    }
  };

  const handleKeyPress = ({ nativeEvent: { key } }, idx) => {
    if (key === 'Backspace' && !otp[idx] && idx > 0) {
      inputRefs.current[idx - 1]?.focus();
    }
  };

  const verify = async (code = otp.join('')) => {
    if (code.length < 6) {
      Alert.alert('Incomplete OTP', 'Please enter all 6 digits.');
      return;
    }
    setLoading(true);
    try {
      const res = await verifyOtp(phone, code);
      const { accessToken, refreshToken, user } = res.data;
      await login({ accessToken, refreshToken }, user);
    } catch (e) {
      Alert.alert('Invalid OTP', e.message);
      setOtp(['', '', '', '', '', '']);
      inputRefs.current[0]?.focus();
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    setResending(true);
    try {
      const res = await resendOtp(phone);
      setTimer(res.data?.cooldownSeconds || 60);
      setOtp(['', '', '', '', '', '']);
      inputRefs.current[0]?.focus();
      Alert.alert('OTP Sent', 'A new OTP has been sent to your number.');
    } catch (e) {
      Alert.alert('Error', e.message);
    } finally {
      setResending(false);
    }
  };

  const formatTime = (s) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <View style={styles.container}>
        {/* Back */}
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.back}>
          <Text style={styles.backText}>← Back</Text>
        </TouchableOpacity>

        {/* Header */}
        <View style={styles.header}>
          <View style={styles.iconBox}>
            <Text style={styles.iconText}>📱</Text>
          </View>
          <Text style={styles.title}>Verify OTP</Text>
          <Text style={styles.subtitle}>
            We sent a 6-digit code to{'\n'}
            <Text style={styles.phone}>{phone}</Text>
          </Text>
        </View>

        {/* OTP Boxes */}
        <View style={styles.otpRow}>
          {otp.map((digit, i) => (
            <TextInput
              key={i}
              ref={r => inputRefs.current[i] = r}
              style={[styles.otpBox, digit && styles.otpBoxFilled]}
              value={digit}
              onChangeText={v => handleChange(v, i)}
              onKeyPress={e => handleKeyPress(e, i)}
              keyboardType="number-pad"
              maxLength={1}
              textContentType="oneTimeCode"
              autoComplete="sms-otp"
            />
          ))}
        </View>

        {/* Timer */}
        <Text style={styles.timer}>
          {timer > 0
            ? `OTP expires in ${formatTime(timer)}`
            : 'OTP expired'}
        </Text>

        {/* Verify Button */}
        <TouchableOpacity
          style={[styles.btn, loading && styles.btnDisabled]}
          onPress={() => verify()}
          disabled={loading}
        >
          {loading
            ? <ActivityIndicator color="#fff" />
            : <Text style={styles.btnText}>Verify & Continue</Text>
          }
        </TouchableOpacity>

        {/* Resend */}
        <TouchableOpacity
          onPress={handleResend}
          disabled={timer > 0 || resending}
          style={styles.resendBtn}
        >
          {resending
            ? <ActivityIndicator size="small" color="#2563EB" />
            : (
              <Text style={[styles.resendText, timer > 0 && styles.resendDisabled]}>
                {timer > 0 ? `Resend in ${formatTime(timer)}` : 'Resend OTP'}
              </Text>
            )
          }
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: '#F0F4FF' },
  container: { flex: 1, padding: 24, justifyContent: 'center' },
  back: { position: 'absolute', top: 56, left: 24 },
  backText: { fontSize: 15, color: '#2563EB', fontWeight: '600' },

  header: { alignItems: 'center', marginBottom: 40 },
  iconBox: {
    width: 72, height: 72, borderRadius: 20, backgroundColor: '#EFF6FF',
    justifyContent: 'center', alignItems: 'center', marginBottom: 16,
  },
  iconText: { fontSize: 36 },
  title: { fontSize: 26, fontWeight: '800', color: '#111827', marginBottom: 8 },
  subtitle: { fontSize: 14, color: '#6B7280', textAlign: 'center', lineHeight: 20 },
  phone: { fontWeight: '700', color: '#2563EB' },

  otpRow: {
    flexDirection: 'row', justifyContent: 'center', gap: 10, marginBottom: 16,
  },
  otpBox: {
    width: 46, height: 54, borderRadius: 12, borderWidth: 2, borderColor: '#E5E7EB',
    textAlign: 'center', fontSize: 22, fontWeight: '700', color: '#111827',
    backgroundColor: '#fff',
  },
  otpBoxFilled: { borderColor: '#2563EB', backgroundColor: '#EFF6FF' },

  timer: { textAlign: 'center', color: '#6B7280', fontSize: 13, marginBottom: 28 },

  btn: {
    backgroundColor: '#2563EB', height: 50, borderRadius: 12,
    justifyContent: 'center', alignItems: 'center',
    shadowColor: '#2563EB', shadowOpacity: 0.3, shadowRadius: 8, elevation: 4,
    marginBottom: 16,
  },
  btnDisabled: { opacity: 0.6 },
  btnText: { color: '#fff', fontSize: 16, fontWeight: '700' },

  resendBtn: { alignItems: 'center', padding: 8 },
  resendText: { fontSize: 14, color: '#2563EB', fontWeight: '600' },
  resendDisabled: { color: '#9CA3AF' },
});
