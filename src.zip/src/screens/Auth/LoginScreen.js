// ─────────────────────────────────────────────────────────────
//  LoginScreen.js  –  Phone number entry
// ─────────────────────────────────────────────────────────────
import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  KeyboardAvoidingView, Platform, ScrollView, ActivityIndicator, Alert,
} from 'react-native';
import { sendOtp } from '../../services/api';

export default function LoginScreen({ navigation }) {
  const [phone, setPhone] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSend = async () => {
    const cleanPhone = phone.trim();
    console.log('📱 cleanPhone:', cleanPhone);  // ← add karo

    if (!/^[6-9]\d{9}$/.test(cleanPhone)) {
      Alert.alert('Invalid Number', 'Enter a valid 10-digit Indian mobile number.');
      return;
    }

    setLoading(true);
    try {
      const res = await sendOtp(
          cleanPhone,
          name.trim() || null,
      );
      console.log('✅ navigate with phone:', cleanPhone);  // ← add karo
      navigation.navigate('Otp', {
        phone: cleanPhone,
        expirySeconds: res.data?.expirySeconds || 120,
        isNewUser: res.data?.newUser,
      });
    } catch (e) {
      Alert.alert('Error', e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
        {/* Logo / Brand */}
        <View style={styles.header}>
          <View style={styles.logoBox}>
            <Text style={styles.logoText}>0Q</Text>
          </View>
          <Text style={styles.brand}>ZeroQ</Text>
          <Text style={styles.tagline}>Shop smarter. Skip the queue.</Text>
        </View>

        {/* Form */}
        <View style={styles.card}>
          <Text style={styles.title}>Welcome</Text>
          <Text style={styles.subtitle}>Enter your mobile number to continue</Text>

          <Text style={styles.label}>Mobile Number</Text>
          <View style={styles.phoneRow}>
            <View style={styles.countryCode}>
              <Text style={styles.countryText}>🇮🇳 +91</Text>
            </View>
            <TextInput
              style={styles.phoneInput}
              placeholder="9876543210"
              placeholderTextColor="#9CA3AF"
              keyboardType="phone-pad"
              maxLength={10}
              value={phone}
              onChangeText={setPhone}
            />
          </View>

          <Text style={styles.label}>Name (for new users)</Text>
          <TextInput
            style={styles.input}
            placeholder="Your full name (optional)"
            placeholderTextColor="#9CA3AF"
            value={name}
            onChangeText={setName}
            autoCapitalize="words"
          />

          <TouchableOpacity
            style={[styles.btn, loading && styles.btnDisabled]}
            onPress={handleSend}
            disabled={loading}
          >
            {loading
              ? <ActivityIndicator color="#fff" />
              : <Text style={styles.btnText}>Send OTP →</Text>
            }
          </TouchableOpacity>

          <Text style={styles.note}>
            We'll send a 6-digit OTP to verify your number.
          </Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: '#F0F4FF' },
  container: { flexGrow: 1, justifyContent: 'center', padding: 24 },
  header: { alignItems: 'center', marginBottom: 32 },
  logoBox: {
    width: 72, height: 72, borderRadius: 20,
    backgroundColor: '#2563EB', justifyContent: 'center', alignItems: 'center',
    marginBottom: 12, shadowColor: '#2563EB', shadowOpacity: 0.4,
    shadowRadius: 12, elevation: 8,
  },
  logoText: { fontSize: 28, fontWeight: '900', color: '#fff' },
  brand: { fontSize: 28, fontWeight: '800', color: '#1E3A8A', letterSpacing: -0.5 },
  tagline: { fontSize: 14, color: '#64748B', marginTop: 4 },

  card: {
    backgroundColor: '#fff', borderRadius: 20, padding: 24,
    shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 16,
    elevation: 4,
  },
  title: { fontSize: 22, fontWeight: '700', color: '#111827', marginBottom: 4 },
  subtitle: { fontSize: 14, color: '#6B7280', marginBottom: 24 },
  label: { fontSize: 13, fontWeight: '600', color: '#374151', marginBottom: 6 },

  phoneRow: { flexDirection: 'row', marginBottom: 16, gap: 8 },
  countryCode: {
    backgroundColor: '#F3F4F6', borderRadius: 10, paddingHorizontal: 14,
    justifyContent: 'center', borderWidth: 1, borderColor: '#E5E7EB',
  },
  countryText: { fontSize: 14, fontWeight: '600', color: '#374151' },
  phoneInput: {
    flex: 1, height: 48, backgroundColor: '#F9FAFB', borderRadius: 10,
    paddingHorizontal: 14, fontSize: 16, color: '#111827',
    borderWidth: 1, borderColor: '#E5E7EB',
  },

  input: {
    height: 48, backgroundColor: '#F9FAFB', borderRadius: 10,
    paddingHorizontal: 14, fontSize: 15, color: '#111827',
    borderWidth: 1, borderColor: '#E5E7EB', marginBottom: 20,
  },

  btn: {
    backgroundColor: '#2563EB', height: 50, borderRadius: 12,
    justifyContent: 'center', alignItems: 'center',
    shadowColor: '#2563EB', shadowOpacity: 0.3, shadowRadius: 8, elevation: 4,
  },
  btnDisabled: { opacity: 0.6 },
  btnText: { color: '#fff', fontSize: 16, fontWeight: '700' },

  note: { textAlign: 'center', color: '#9CA3AF', fontSize: 12, marginTop: 16 },
});
