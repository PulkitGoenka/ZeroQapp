// ─────────────────────────────────────────────────────────────
//  StoreSelectScreen.js  –  Find store by pincode / state / QR
// ─────────────────────────────────────────────────────────────
import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  ScrollView, ActivityIndicator, Alert, FlatList,
} from 'react-native';
import { Feather as Icon } from '@expo/vector-icons';
import { findStoresByPincode, findStoresByState, startSession } from '../../services/api';
import { useAuth } from '../../store/AuthContext';

const TABS = ['Pincode', 'State'];

const INDIAN_STATES = [
  'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh',
  'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka',
  'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram',
  'Nagaland', 'Odisha', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu',
  'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal',
  'Delhi', 'Jammu and Kashmir', 'Ladakh',
];

export default function StoreSelectScreen({ navigation }) {
  const { session, saveSession } = useAuth();
  const [tab, setTab] = useState(0);
  const [pincode, setPincode] = useState('');
  const [state, setState] = useState('');
  const [stores, setStores] = useState([]);
  const [loading, setLoading] = useState(false);
  const [starting, setStarting] = useState(null); // storeId being started

  const search = async () => {
    setLoading(true);
    setStores([]);
    try {
      let res;
      if (tab === 0) {
        if (!/^\d{6}$/.test(pincode.trim())) {
          Alert.alert('Invalid Pincode', 'Enter a valid 6-digit pincode.');
          return;
        }
        res = await findStoresByPincode(pincode.trim());
      } else {
        if (!state.trim()) {
          Alert.alert('Select State', 'Please enter a state name.');
          return;
        }
        res = await findStoresByState(state.trim());
      }
      setStores(res.data || []);
      if (!res.data?.length) Alert.alert('No Stores', 'No stores found for your search.');
    } catch (e) {
      Alert.alert('Error', e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectStore = async (store) => {
    if (session) {
      Alert.alert(
        'Active Session',
        `You have an active session at ${session.storeName}. End it first.`,
      );
      return;
    }
    setStarting(store.id);
    try {
      const res = await startSession(store.id);
      await saveSession(res.data);
      navigation.navigate('Cart');
    } catch (e) {
      Alert.alert('Error', e.message);
    } finally {
      setStarting(null);
    }
  };

  return (
    <View style={styles.flex}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Icon name="arrow-left" size={20} color="#374151" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Find a Store</Text>
        <View style={{ width: 36 }} />
      </View>

      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">

        {/* Tab switcher */}
        <View style={styles.tabs}>
          {TABS.map((t, i) => (
            <TouchableOpacity
              key={t} onPress={() => { setTab(i); setStores([]); }}
              style={[styles.tab, tab === i && styles.tabActive]}
            >
              <Text style={[styles.tabText, tab === i && styles.tabTextActive]}>{t}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Input */}
        {tab === 0 ? (
          <TextInput
            style={styles.input}
            placeholder="Enter 6-digit pincode"
            placeholderTextColor="#9CA3AF"
            keyboardType="number-pad"
            maxLength={6}
            value={pincode}
            onChangeText={setPincode}
          />
        ) : (
          <TextInput
            style={styles.input}
            placeholder="Enter state name (e.g. Uttar Pradesh)"
            placeholderTextColor="#9CA3AF"
            value={state}
            onChangeText={setState}
            autoCapitalize="words"
          />
        )}

        <TouchableOpacity
          style={[styles.searchBtn, loading && styles.btnDisabled]}
          onPress={search}
          disabled={loading}
        >
          {loading
            ? <ActivityIndicator color="#fff" />
            : <>
              <Icon name="search" size={16} color="#fff" />
              <Text style={styles.searchBtnText}>Search Stores</Text>
            </>
          }
        </TouchableOpacity>

        {/* Store list */}
        {stores.map(store => (
          <TouchableOpacity
            key={store.id}
            style={styles.storeCard}
            onPress={() => handleSelectStore(store)}
            disabled={starting === store.id}
          >
            <View style={styles.storeLogo}>
              <Text style={styles.storeLogoText}>
                {store.brandName?.charAt(0) || '?'}
              </Text>
            </View>
            <View style={styles.storeInfo}>
              <Text style={styles.storeName}>{store.name}</Text>
              <Text style={styles.storeBrand}>{store.brandName}</Text>
              <Text style={styles.storeAddr} numberOfLines={1}>
                {store.address}, {store.city} – {store.pincode}
              </Text>
            </View>
            {starting === store.id
              ? <ActivityIndicator color="#2563EB" />
              : <Icon name="chevron-right" size={18} color="#9CA3AF" />
            }
          </TouchableOpacity>
        ))}

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: '#F9FAFB' },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingTop: 52, paddingBottom: 16,
    backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#E5E7EB',
  },
  backBtn: { width: 36, height: 36, justifyContent: 'center', alignItems: 'center' },
  headerTitle: { fontSize: 17, fontWeight: '700', color: '#111827' },
  scroll: { padding: 20, paddingBottom: 40 },

  tabs: {
    flexDirection: 'row', backgroundColor: '#F3F4F6', borderRadius: 12,
    padding: 4, marginBottom: 16,
  },
  tab: { flex: 1, paddingVertical: 8, borderRadius: 8, alignItems: 'center' },
  tabActive: { backgroundColor: '#fff', shadowColor: '#000', shadowOpacity: 0.08, shadowRadius: 4, elevation: 2 },
  tabText: { fontSize: 14, fontWeight: '600', color: '#6B7280' },
  tabTextActive: { color: '#2563EB' },

  input: {
    height: 48, backgroundColor: '#fff', borderRadius: 12, paddingHorizontal: 16,
    fontSize: 15, color: '#111827', borderWidth: 1, borderColor: '#E5E7EB',
    marginBottom: 12,
  },
  searchBtn: {
    backgroundColor: '#2563EB', height: 48, borderRadius: 12,
    flexDirection: 'row', justifyContent: 'center', alignItems: 'center',
    gap: 8, marginBottom: 24, elevation: 2,
  },
  btnDisabled: { opacity: 0.6 },
  searchBtnText: { color: '#fff', fontSize: 15, fontWeight: '700' },

  storeCard: {
    backgroundColor: '#fff', borderRadius: 14, padding: 14,
    flexDirection: 'row', alignItems: 'center', gap: 12,
    marginBottom: 10, shadowColor: '#000', shadowOpacity: 0.05,
    shadowRadius: 6, elevation: 2,
  },
  storeLogo: {
    width: 44, height: 44, borderRadius: 12, backgroundColor: '#EFF6FF',
    justifyContent: 'center', alignItems: 'center',
  },
  storeLogoText: { fontSize: 20, fontWeight: '800', color: '#2563EB' },
  storeInfo: { flex: 1 },
  storeName: { fontSize: 14, fontWeight: '700', color: '#111827' },
  storeBrand: { fontSize: 12, color: '#2563EB', fontWeight: '600', marginTop: 1 },
  storeAddr: { fontSize: 11, color: '#6B7280', marginTop: 2 },
});
