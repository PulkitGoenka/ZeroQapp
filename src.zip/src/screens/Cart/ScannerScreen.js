// ─────────────────────────────────────────────────────────────
//  ScannerScreen.js  –  Expo Compatible Version
//  Uses: expo-camera (built-in barcode scanning)
//  Replace: react-native-vision-camera (bare RN only)
// ─────────────────────────────────────────────────────────────
import React, { useState, useCallback, useRef } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, Vibration,
} from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { Feather as Icon } from '@expo/vector-icons';  // ← Expo icons
import { scanBarcode } from '../../services/api';
import { useAuth } from '../../store/AuthContext';

export default function ScannerScreen({ navigation }) {
  const { session } = useAuth();
  const [permission, requestPermission] = useCameraPermissions();

  const [scanning, setScanning]       = useState(true);
  const [lastScanned, setLastScanned] = useState(null);
  const [feedbackMsg, setFeedbackMsg] = useState('');
  const [feedbackType, setFeedbackType] = useState('');
  const cooldown = useRef(false);

  const showFeedback = (msg, type) => {
    setFeedbackMsg(msg);
    setFeedbackType(type);
    setTimeout(() => { setFeedbackMsg(''); setFeedbackType(''); }, 2500);
  };

  const handleBarcode = useCallback(async ({ data }) => {
    if (!scanning || cooldown.current || !data) return;
    if (data === lastScanned) return;

    cooldown.current = true;
    setTimeout(() => { cooldown.current = false; }, 2000);

    setLastScanned(data);
    setScanning(false);
    Vibration.vibrate(80);

    try {
      await scanBarcode(data, session?.sessionId);
      showFeedback('✓ Product added to cart!', 'success');
    } catch (e) {
      showFeedback(`✗ ${e.message}`, 'error');
    } finally {
      setTimeout(() => setScanning(true), 2000);
    }
  }, [scanning, lastScanned, session]);

  // Permission nahi mila
  if (!permission) {
    return <View style={styles.permissionBox} />;
  }

  // Permission maango
  if (!permission.granted) {
    return (
        <View style={styles.permissionBox}>
          <Text style={styles.permIcon}>📷</Text>
          <Text style={styles.permTitle}>Camera Permission Chahiye</Text>
          <Text style={styles.permText}>
            Barcode scan karne ke liye camera access allow karo.
          </Text>
          <TouchableOpacity style={styles.allowBtn} onPress={requestPermission}>
            <Text style={styles.allowBtnText}>Allow Camera</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
            <Text style={styles.backBtnText}>Go Back</Text>
          </TouchableOpacity>
        </View>
    );
  }

  return (
      <View style={styles.flex}>

        {/* Camera with barcode scanning */}
        <CameraView
            style={StyleSheet.absoluteFill}
            facing="back"
            barcodeScannerSettings={{
              barcodeTypes: ['ean13', 'ean8', 'qr', 'code128', 'code39', 'upc_a'],
            }}
            onBarcodeScanned={scanning ? handleBarcode : undefined}
        />

        {/* Overlay */}
        <View style={styles.overlay}>

          {/* Top bar */}
          <View style={styles.topBar}>
            <TouchableOpacity onPress={() => navigation.goBack()} style={styles.closeBtn}>
              <Icon name="x" size={22} color="#fff" />
            </TouchableOpacity>
            <Text style={styles.scannerTitle}>Scan Barcode</Text>
            <TouchableOpacity
                onPress={() => navigation.navigate('Cart')}
                style={styles.cartBtn}
            >
              <Icon name="shopping-cart" size={20} color="#fff" />
            </TouchableOpacity>
          </View>

          {/* Viewfinder frame */}
          <View style={styles.viewfinder}>
            <View style={[styles.corner, styles.tl]} />
            <View style={[styles.corner, styles.tr]} />
            <View style={[styles.corner, styles.bl]} />
            <View style={[styles.corner, styles.br]} />
          </View>

          <Text style={styles.hint}>Point camera at product barcode</Text>

          {/* Feedback banner */}
          {!!feedbackMsg && (
              <View style={[
                styles.feedbackBanner,
                feedbackType === 'success' ? styles.feedbackSuccess : styles.feedbackError,
              ]}>
                <Text style={styles.feedbackText}>{feedbackMsg}</Text>
              </View>
          )}

          {/* Last scanned code */}
          {lastScanned && (
              <View style={styles.lastScanned}>
                <Text style={styles.lastScannedLabel}>Last scanned:</Text>
                <Text style={styles.lastScannedCode}>{lastScanned}</Text>
              </View>
          )}

          {/* Go to Cart */}
          <TouchableOpacity
              style={styles.goCartBtn}
              onPress={() => navigation.navigate('Cart')}
          >
            <Text style={styles.goCartText}>View Cart & Pay →</Text>
          </TouchableOpacity>

        </View>
      </View>
  );
}

const CORNER_SIZE  = 24;
const CORNER_THICK = 3;
const VIEWFINDER_SIZE = 240;

const styles = StyleSheet.create({
  flex: { flex: 1 },

  permissionBox: {
    flex: 1, justifyContent: 'center', alignItems: 'center',
    padding: 32, backgroundColor: '#111',
  },
  permIcon:  { fontSize: 56, marginBottom: 16 },
  permTitle: { fontSize: 20, fontWeight: '700', color: '#fff', marginBottom: 8 },
  permText:  { fontSize: 13, color: '#9CA3AF', textAlign: 'center', lineHeight: 20, marginBottom: 24 },

  allowBtn: {
    backgroundColor: '#2563EB', paddingHorizontal: 24,
    paddingVertical: 10, borderRadius: 10, marginBottom: 10,
  },
  allowBtnText: { color: '#fff', fontWeight: '700' },

  backBtn: {
    backgroundColor: '#374151', paddingHorizontal: 24,
    paddingVertical: 10, borderRadius: 10,
  },
  backBtnText: { color: '#fff', fontWeight: '700' },

  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.55)', alignItems: 'center' },

  topBar: {
    width: '100%', flexDirection: 'row', alignItems: 'center',
    paddingTop: 52, paddingHorizontal: 16, paddingBottom: 16,
  },
  closeBtn:     { padding: 6 },
  scannerTitle: { flex: 1, textAlign: 'center', color: '#fff', fontSize: 16, fontWeight: '700' },
  cartBtn:      { padding: 6 },

  viewfinder: {
    width: VIEWFINDER_SIZE, height: VIEWFINDER_SIZE,
    marginTop: 60, position: 'relative',
  },
  corner: {
    position: 'absolute', width: CORNER_SIZE, height: CORNER_SIZE,
    borderColor: '#fff', backgroundColor: 'transparent',
  },
  tl: { top: 0, left: 0, borderTopWidth: CORNER_THICK, borderLeftWidth: CORNER_THICK, borderTopLeftRadius: 4 },
  tr: { top: 0, right: 0, borderTopWidth: CORNER_THICK, borderRightWidth: CORNER_THICK, borderTopRightRadius: 4 },
  bl: { bottom: 0, left: 0, borderBottomWidth: CORNER_THICK, borderLeftWidth: CORNER_THICK, borderBottomLeftRadius: 4 },
  br: { bottom: 0, right: 0, borderBottomWidth: CORNER_THICK, borderRightWidth: CORNER_THICK, borderBottomRightRadius: 4 },

  hint: { color: '#E5E7EB', fontSize: 13, marginTop: 20, fontWeight: '500' },

  feedbackBanner: {
    marginTop: 20, paddingHorizontal: 20, paddingVertical: 10,
    borderRadius: 10, minWidth: 220, alignItems: 'center',
  },
  feedbackSuccess: { backgroundColor: '#059669' },
  feedbackError:   { backgroundColor: '#DC2626' },
  feedbackText:    { color: '#fff', fontWeight: '700', fontSize: 14 },

  lastScanned:      { marginTop: 16, alignItems: 'center' },
  lastScannedLabel: { color: '#9CA3AF', fontSize: 11 },
  lastScannedCode:  { color: '#fff', fontSize: 14, fontWeight: '600', letterSpacing: 1 },

  goCartBtn: {
    position: 'absolute', bottom: 48,
    backgroundColor: '#2563EB', paddingHorizontal: 28, paddingVertical: 14,
    borderRadius: 14, elevation: 4,
    shadowColor: '#2563EB', shadowOpacity: 0.4, shadowRadius: 10,
  },
  goCartText: { color: '#fff', fontSize: 15, fontWeight: '700' },
});