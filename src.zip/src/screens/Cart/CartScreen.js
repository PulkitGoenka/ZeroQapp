// ─────────────────────────────────────────────────────────────
//  CartScreen.js  –  View cart, update qty, go to payment
// ─────────────────────────────────────────────────────────────
import React, { useEffect, useState, useCallback } from 'react';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet,
  ActivityIndicator, Alert, RefreshControl, Image,
} from 'react-native';
import { Feather as Icon } from '@expo/vector-icons';
import { getCart, updateQuantity, removeItem } from '../../services/api';
import { useAuth } from '../../store/AuthContext';

const fmt = (n) => `₹${Number(n).toFixed(2)}`;

function CartItem({ item, onInc, onDec, onRemove, updating }) {
  return (
    <View style={styles.itemCard}>
      <View style={styles.itemImgBox}>
        {item.imageUrl
          ? <Image source={{ uri: item.imageUrl }} style={styles.itemImg} />
          : <Text style={styles.itemPlaceholder}>📦</Text>
        }
      </View>
      <View style={styles.itemInfo}>
        <Text style={styles.itemName} numberOfLines={2}>{item.productName}</Text>
        <View style={styles.priceRow}>
          <Text style={styles.discPrice}>{fmt(item.discountPrice)}</Text>
          {item.mrp !== item.discountPrice && (
            <Text style={styles.mrp}>{fmt(item.mrp)}</Text>
          )}
          {item.discountPct > 0 && (
            <View style={styles.discBadge}>
              <Text style={styles.discBadgeText}>{item.discountPct}% off</Text>
            </View>
          )}
        </View>
        <Text style={styles.lineTotal}>Total: {fmt(item.lineTotal)}</Text>
      </View>
      <View style={styles.qtyCol}>
        <TouchableOpacity onPress={onRemove} style={styles.removeBtn} disabled={updating}>
          <Icon name="trash-2" size={14} color="#EF4444" />
        </TouchableOpacity>
        <View style={styles.qtyRow}>
          <TouchableOpacity style={styles.qtyBtn} onPress={onDec} disabled={updating}>
            <Text style={styles.qtyBtnText}>−</Text>
          </TouchableOpacity>
          <Text style={styles.qty}>{item.quantity}</Text>
          <TouchableOpacity style={styles.qtyBtn} onPress={onInc} disabled={updating}>
            <Text style={styles.qtyBtnText}>+</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

export default function CartScreen({ navigation }) {
  const { session } = useAuth();
  const [cart, setCart] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [updating, setUpdating] = useState(false);

  const fetchCart = useCallback(async () => {
    if (!session) { setLoading(false); return; }
    try {
      const res = await getCart();
      setCart(res.data);
    } catch (e) {
      Alert.alert('Error', e.message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [session]);

  useEffect(() => { fetchCart(); }, [fetchCart]);

  const handleQty = async (barcode, qty) => {
    if (qty < 0) return;
    setUpdating(true);
    try {
      const res = await updateQuantity(barcode, qty);
      setCart(res.data);
    } catch (e) {
      Alert.alert('Error', e.message);
    } finally {
      setUpdating(false);
    }
  };

  const handleRemove = async (barcode) => {
    Alert.alert('Remove Item', 'Remove this item from cart?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove', style: 'destructive', onPress: async () => {
          setUpdating(true);
          try {
            const res = await removeItem(barcode);
            setCart(res.data);
          } catch (e) {
            Alert.alert('Error', e.message);
          } finally {
            setUpdating(false);
          }
        }
      },
    ]);
  };

  // No session
  if (!session) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyIcon}>🛒</Text>
        <Text style={styles.emptyTitle}>No Active Session</Text>
        <Text style={styles.emptyText}>Please select a store to start shopping.</Text>
        <TouchableOpacity
          style={styles.startBtn}
          onPress={() => navigation.navigate('StoreSelect')}
        >
          <Text style={styles.startBtnText}>Find a Store</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (loading) {
    return (
      <View style={styles.emptyContainer}>
        <ActivityIndicator size="large" color="#2563EB" />
      </View>
    );
  }

  const hasItems = cart?.items?.length > 0;

  return (
    <View style={styles.flex}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>My Cart</Text>
        <Text style={styles.headerStore}>{cart?.storeName || session?.storeName}</Text>
        <TouchableOpacity
          style={styles.scanBtn}
          onPress={() => navigation.navigate('Scanner')}
        >
          <Icon name="camera" size={18} color="#fff" />
          <Text style={styles.scanBtnText}>Scan</Text>
        </TouchableOpacity>
      </View>

      {hasItems ? (
        <>
          <FlatList
            data={cart.items}
            keyExtractor={i => i.barcode}
            renderItem={({ item }) => (
              <CartItem
                item={item}
                updating={updating}
                onInc={() => handleQty(item.barcode, item.quantity + 1)}
                onDec={() => handleQty(item.barcode, item.quantity - 1)}
                onRemove={() => handleRemove(item.barcode)}
              />
            )}
            contentContainerStyle={styles.list}
            refreshControl={
              <RefreshControl refreshing={refreshing} onRefresh={() => {
                setRefreshing(true); fetchCart();
              }} />
            }
          />

          {/* Summary */}
          <View style={styles.summary}>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Subtotal</Text>
              <Text style={styles.summaryVal}>{fmt(cart.subtotal)}</Text>
            </View>
            {cart.totalDiscount > 0 && (
              <View style={styles.summaryRow}>
                <Text style={[styles.summaryLabel, { color: '#059669' }]}>Discount</Text>
                <Text style={[styles.summaryVal, { color: '#059669' }]}>
                  −{fmt(cart.totalDiscount)}
                </Text>
              </View>
            )}
            <View style={[styles.summaryRow, styles.totalRow]}>
              <Text style={styles.totalLabel}>Total ({cart.itemCount} items)</Text>
              <Text style={styles.totalAmt}>{fmt(cart.totalAmount)}</Text>
            </View>
            <TouchableOpacity
              style={styles.payBtn}
              onPress={() => navigation.navigate('Payment')}
            >
              <Icon name="credit-card" size={18} color="#fff" />
              <Text style={styles.payBtnText}>Proceed to Pay</Text>
            </TouchableOpacity>
          </View>
        </>
      ) : (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyIcon}>📷</Text>
          <Text style={styles.emptyTitle}>Cart is Empty</Text>
          <Text style={styles.emptyText}>Scan a product barcode to add items to your cart.</Text>
          <TouchableOpacity
            style={styles.startBtn}
            onPress={() => navigation.navigate('Scanner')}
          >
            <Icon name="camera" size={16} color="#fff" />
            <Text style={styles.startBtnText}>  Start Scanning</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: '#F9FAFB' },
  header: {
    paddingHorizontal: 20, paddingTop: 56, paddingBottom: 16,
    backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#E5E7EB',
    flexDirection: 'row', alignItems: 'center', gap: 8,
  },
  headerTitle: { fontSize: 18, fontWeight: '800', color: '#111827' },
  headerStore: { flex: 1, fontSize: 12, color: '#6B7280', fontWeight: '500' },
  scanBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: '#2563EB', paddingHorizontal: 14, paddingVertical: 8,
    borderRadius: 10,
  },
  scanBtnText: { color: '#fff', fontSize: 13, fontWeight: '700' },

  list: { padding: 16, paddingBottom: 8, gap: 10 },

  itemCard: {
    backgroundColor: '#fff', borderRadius: 14, padding: 12,
    flexDirection: 'row', gap: 10, shadowColor: '#000',
    shadowOpacity: 0.04, shadowRadius: 6, elevation: 2,
  },
  itemImgBox: {
    width: 70, height: 70, borderRadius: 10, backgroundColor: '#F3F4F6',
    justifyContent: 'center', alignItems: 'center',
  },
  itemImg: { width: 70, height: 70, borderRadius: 10 },
  itemPlaceholder: { fontSize: 28 },
  itemInfo: { flex: 1 },
  itemName: { fontSize: 13, fontWeight: '600', color: '#111827', lineHeight: 18 },
  priceRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 4 },
  discPrice: { fontSize: 15, fontWeight: '800', color: '#111827' },
  mrp: { fontSize: 12, color: '#9CA3AF', textDecorationLine: 'line-through' },
  discBadge: { backgroundColor: '#DCFCE7', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4 },
  discBadgeText: { fontSize: 10, color: '#059669', fontWeight: '700' },
  lineTotal: { fontSize: 11, color: '#6B7280', marginTop: 4 },

  qtyCol: { alignItems: 'center', justifyContent: 'space-between' },
  removeBtn: { padding: 4 },
  qtyRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  qtyBtn: {
    width: 28, height: 28, borderRadius: 8, backgroundColor: '#EFF6FF',
    justifyContent: 'center', alignItems: 'center',
  },
  qtyBtnText: { fontSize: 16, fontWeight: '700', color: '#2563EB' },
  qty: { fontSize: 15, fontWeight: '700', color: '#111827', minWidth: 20, textAlign: 'center' },

  summary: {
    backgroundColor: '#fff', paddingHorizontal: 20, paddingVertical: 16,
    borderTopWidth: 1, borderTopColor: '#E5E7EB', gap: 8,
  },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between' },
  summaryLabel: { fontSize: 13, color: '#6B7280' },
  summaryVal: { fontSize: 13, fontWeight: '600', color: '#374151' },
  totalRow: { borderTopWidth: 1, borderTopColor: '#E5E7EB', paddingTop: 8, marginTop: 4 },
  totalLabel: { fontSize: 15, fontWeight: '700', color: '#111827' },
  totalAmt: { fontSize: 17, fontWeight: '800', color: '#111827' },
  payBtn: {
    backgroundColor: '#2563EB', height: 50, borderRadius: 12, marginTop: 4,
    flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8,
    elevation: 3,
  },
  payBtnText: { color: '#fff', fontSize: 15, fontWeight: '700' },

  emptyContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 32 },
  emptyIcon: { fontSize: 56, marginBottom: 16 },
  emptyTitle: { fontSize: 20, fontWeight: '700', color: '#111827', marginBottom: 8 },
  emptyText: { fontSize: 14, color: '#6B7280', textAlign: 'center', lineHeight: 20, marginBottom: 24 },
  startBtn: {
    backgroundColor: '#2563EB', paddingHorizontal: 24, paddingVertical: 12,
    borderRadius: 12, flexDirection: 'row', alignItems: 'center',
  },
  startBtnText: { color: '#fff', fontSize: 15, fontWeight: '700' },
});
