// ─────────────────────────────────────────────────────────────
//  PaymentQrScreen.js  –  Show QR code for exit gate / counter
// ─────────────────────────────────────────────────────────────
import React, { useEffect, useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, Image, Alert,
} from 'react-native';
import { Feather as Icon } from '@expo/vector-icons';
import { useAuth } from '../../store/AuthContext';

export default function PaymentQrScreen({ navigation, route }) {
  const { paymentData, method } = route.params;
  const { clearSession } = useAuth();
  const [timer, setTimer] = useState(paymentData?.qrExpirySeconds || 300);

  // Countdown
  useEffect(() => {
    const interval = setInterval(() => {
      setTimer(t => {
        if (t <= 1) {
          clearInterval(interval);
          Alert.alert('QR Expired', 'Your QR code has expired. Please go back and try again.');
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const formatTime = (s) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;

  const handleDone = async () => {
    // Session ends on backend after verify-exit-qr or confirm-cash
    // Frontend clears its local session state
    await clearSession();
    navigation.reset({ index: 0, routes: [{ name: 'MainTabs' }] });
  };

  const isCash = method === 'cash';
  const qrUri = paymentData?.qrImageBase64
    ? `data:image/png;base64,${paymentData.qrImageBase64}`
    : null;

  return (
    <View style={styles.flex}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>
          {isCash ? '💵 Cash Payment' : '💳 Online Payment'}
        </Text>
      </View>

      <View style={styles.content}>
        {/* Instruction card */}
        <View style={[styles.instrCard, isCash ? styles.instrCash : styles.instrOnline]}>
          <Text style={styles.instrEmoji}>{isCash ? '🏪' : '🚪'}</Text>
          <View>
            <Text style={styles.instrTitle}>
              {isCash ? 'Show at Billing Counter' : 'Show at Exit Gate'}
            </Text>
            <Text style={styles.instrText}>
              {isCash
                ? 'Present this QR to the billing staff to process your cash payment.'
                : 'Pay online via your UPI/banking app first, then show this QR at the exit gate.'}
            </Text>
          </View>
        </View>

        {/* QR Code */}
        <View style={styles.qrBox}>
          {qrUri ? (
            <Image source={{ uri: qrUri }} style={styles.qrImage} resizeMode="contain" />
          ) : (
            <View style={styles.qrPlaceholder}>
              <Icon name="grid" size={80} color="#CBD5E1" />
              <Text style={styles.qrToken}>{paymentData?.qrToken}</Text>
            </View>
          )}
        </View>

        {/* Timer */}
        <View style={styles.timerRow}>
          <Icon name="clock" size={14} color={timer < 60 ? '#EF4444' : '#6B7280'} />
          <Text style={[styles.timerText, timer < 60 && styles.timerRed]}>
            Expires in {formatTime(timer)}
          </Text>
        </View>

        {/* Amount */}
        <View style={styles.amtRow}>
          <Text style={styles.amtLabel}>Total Amount</Text>
          <Text style={styles.amtValue}>₹{Number(paymentData?.totalAmount || 0).toFixed(2)}</Text>
        </View>

        {/* Order ID */}
        <Text style={styles.orderId}>Order ID: {paymentData?.orderId}</Text>

        {/* Online payment: external pay prompt */}
        {!isCash && (
          <View style={styles.payPromptCard}>
            <Text style={styles.payPromptTitle}>💡 How to pay online</Text>
            <Text style={styles.payPromptText}>
              1. Open your UPI app (GPay, PhonePe, Paytm, etc.){'\n'}
              2. Send ₹{Number(paymentData?.totalAmount || 0).toFixed(2)} to the store{'\n'}
              3. Come back and show this QR at the exit gate
            </Text>
          </View>
        )}

        {/* Done button (marks session done on client side) */}
        <TouchableOpacity style={styles.doneBtn} onPress={handleDone}>
          <Text style={styles.doneBtnText}>✓ Payment Done – Go to Home</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: '#F9FAFB' },
  header: {
    paddingHorizontal: 20, paddingTop: 52, paddingBottom: 16,
    backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#E5E7EB',
    alignItems: 'center',
  },
  headerTitle: { fontSize: 17, fontWeight: '700', color: '#111827' },
  content: { flex: 1, padding: 20, alignItems: 'center', gap: 14 },

  instrCard: {
    width: '100%', borderRadius: 14, padding: 14,
    flexDirection: 'row', gap: 12, alignItems: 'flex-start',
  },
  instrOnline: { backgroundColor: '#EFF6FF' },
  instrCash: { backgroundColor: '#FFFBEB' },
  instrEmoji: { fontSize: 28, marginTop: 2 },
  instrTitle: { fontSize: 14, fontWeight: '700', color: '#111827', marginBottom: 4 },
  instrText: { fontSize: 12, color: '#374151', lineHeight: 16, flex: 1, flexWrap: 'wrap' },

  qrBox: {
    backgroundColor: '#fff', borderRadius: 18, padding: 20,
    shadowColor: '#000', shadowOpacity: 0.08, shadowRadius: 16, elevation: 4,
  },
  qrImage: { width: 220, height: 220 },
  qrPlaceholder: { width: 220, height: 220, justifyContent: 'center', alignItems: 'center', gap: 12 },
  qrToken: { fontSize: 12, color: '#6B7280', textAlign: 'center', letterSpacing: 0.5 },

  timerRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  timerText: { fontSize: 13, color: '#6B7280', fontWeight: '600' },
  timerRed: { color: '#EF4444' },

  amtRow: { flexDirection: 'row', gap: 8, alignItems: 'baseline' },
  amtLabel: { fontSize: 14, color: '#6B7280' },
  amtValue: { fontSize: 24, fontWeight: '800', color: '#111827' },

  orderId: { fontSize: 11, color: '#9CA3AF' },

  payPromptCard: {
    width: '100%', backgroundColor: '#F0FDF4', borderRadius: 12,
    padding: 14, borderLeftWidth: 3, borderLeftColor: '#059669',
  },
  payPromptTitle: { fontSize: 13, fontWeight: '700', color: '#065F46', marginBottom: 6 },
  payPromptText: { fontSize: 12, color: '#047857', lineHeight: 20 },

  doneBtn: {
    width: '100%', backgroundColor: '#059669', height: 50, borderRadius: 12,
    justifyContent: 'center', alignItems: 'center', elevation: 3,
    shadowColor: '#059669', shadowOpacity: 0.3, shadowRadius: 8,
  },
  doneBtnText: { color: '#fff', fontSize: 15, fontWeight: '700' },
});
