// ─────────────────────────────────────────────────────────────
//  PaymentScreen.js  –  Choose payment method
// ─────────────────────────────────────────────────────────────
import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ActivityIndicator, Alert,
} from 'react-native';
import { Feather as Icon } from '@expo/vector-icons';
import { initiateOnlinePayment, initiateCashPayment } from '../../services/api';
import { useAuth } from '../../store/AuthContext';

const PayMethod = ({ icon, emoji, title, desc, selected, onPress }) => (
  <TouchableOpacity
    style={[styles.methodCard, selected && styles.methodSelected]}
    onPress={onPress}
  >
    <Text style={styles.methodEmoji}>{emoji}</Text>
    <View style={styles.methodInfo}>
      <Text style={[styles.methodTitle, selected && styles.methodTitleSel]}>{title}</Text>
      <Text style={styles.methodDesc}>{desc}</Text>
    </View>
    <View style={[styles.radio, selected && styles.radioSel]}>
      {selected && <View style={styles.radioDot} />}
    </View>
  </TouchableOpacity>
);

export default function PaymentScreen({ navigation }) {
  const { session, cart } = useAuth();
  const [method, setMethod] = useState(null); // 'online' | 'cash'
  const [loading, setLoading] = useState(false);

  const handlePay = async () => {
    if (!method) {
      Alert.alert('Choose Method', 'Please select a payment method first.');
      return;
    }
    setLoading(true);
    try {
      let res;
      if (method === 'online') {
        res = await initiateOnlinePayment();
      } else {
        res = await initiateCashPayment();
      }
      navigation.navigate('PaymentQr', {
        paymentData: res.data,
        method,
      });
    } catch (e) {
      Alert.alert('Payment Error', e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.flex}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Icon name="arrow-left" size={20} color="#374151" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Choose Payment</Text>
        <View style={{ width: 36 }} />
      </View>

      <View style={styles.content}>
        {/* Total amount */}
        <View style={styles.totalCard}>
          <Text style={styles.totalLabel}>Amount to Pay</Text>
          <Text style={styles.totalAmount}>
            ₹{Number(cart?.totalAmount || 0).toFixed(2)}
          </Text>
          <Text style={styles.totalStore}>{session?.storeName}</Text>
        </View>

        <Text style={styles.sectionTitle}>Select Payment Method</Text>

        <PayMethod
          emoji="💳"
          title="Pay Online"
          desc="UPI, Debit/Credit Card, Net Banking. Get a QR to show at exit gate."
          selected={method === 'online'}
          onPress={() => setMethod('online')}
        />

        <PayMethod
          emoji="💵"
          title="Pay Cash at Counter"
          desc="Get a QR code to show the billing counter. Pay cash there."
          selected={method === 'cash'}
          onPress={() => setMethod('cash')}
        />

        {/* Info notes */}
        {method === 'online' && (
          <View style={styles.infoBox}>
            <Icon name="info" size={14} color="#2563EB" />
            <Text style={styles.infoText}>
              After initiating, you cannot edit the cart. Pay online via your UPI app, then show the QR at the exit gate.
            </Text>
          </View>
        )}
        {method === 'cash' && (
          <View style={styles.infoBox}>
            <Icon name="info" size={14} color="#D97706" />
            <Text style={[styles.infoText, { color: '#92400E' }]}>
              Show the QR to the billing counter staff. They'll confirm your payment.
            </Text>
          </View>
        )}

        <TouchableOpacity
          style={[styles.payBtn, (!method || loading) && styles.payBtnDisabled]}
          onPress={handlePay}
          disabled={!method || loading}
        >
          {loading
            ? <ActivityIndicator color="#fff" />
            : <>
              <Icon name="arrow-right" size={18} color="#fff" />
              <Text style={styles.payBtnText}>Generate QR Code</Text>
            </>
          }
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: '#F9FAFB' },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingTop: 52, paddingBottom: 16,
    backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#E5E7EB',
  },
  backBtn: { width: 36, height: 36, justifyContent: 'center', alignItems: 'center' },
  headerTitle: { fontSize: 17, fontWeight: '700', color: '#111827' },
  content: { flex: 1, padding: 20, gap: 14 },

  totalCard: {
    backgroundColor: '#2563EB', borderRadius: 18, padding: 20, alignItems: 'center',
    shadowColor: '#2563EB', shadowOpacity: 0.3, shadowRadius: 12, elevation: 6,
  },
  totalLabel: { fontSize: 12, color: '#BFDBFE', fontWeight: '600', textTransform: 'uppercase', letterSpacing: 0.5 },
  totalAmount: { fontSize: 40, fontWeight: '900', color: '#fff', marginTop: 4 },
  totalStore: { fontSize: 12, color: '#93C5FD', marginTop: 4 },

  sectionTitle: { fontSize: 15, fontWeight: '700', color: '#374151' },

  methodCard: {
    backgroundColor: '#fff', borderRadius: 14, padding: 16,
    flexDirection: 'row', alignItems: 'center', gap: 14,
    borderWidth: 2, borderColor: '#E5E7EB',
    shadowColor: '#000', shadowOpacity: 0.04, shadowRadius: 6, elevation: 1,
  },
  methodSelected: { borderColor: '#2563EB', backgroundColor: '#EFF6FF' },
  methodEmoji: { fontSize: 28 },
  methodInfo: { flex: 1 },
  methodTitle: { fontSize: 15, fontWeight: '700', color: '#111827' },
  methodTitleSel: { color: '#2563EB' },
  methodDesc: { fontSize: 12, color: '#6B7280', marginTop: 2, lineHeight: 16 },
  radio: {
    width: 22, height: 22, borderRadius: 11, borderWidth: 2,
    borderColor: '#D1D5DB', justifyContent: 'center', alignItems: 'center',
  },
  radioSel: { borderColor: '#2563EB' },
  radioDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: '#2563EB' },

  infoBox: {
    backgroundColor: '#EFF6FF', borderRadius: 10, padding: 12,
    flexDirection: 'row', gap: 8, alignItems: 'flex-start',
  },
  infoText: { flex: 1, fontSize: 12, color: '#1E40AF', lineHeight: 16 },

  payBtn: {
    backgroundColor: '#2563EB', height: 52, borderRadius: 14, marginTop: 8,
    flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8,
    elevation: 4, shadowColor: '#2563EB', shadowOpacity: 0.3, shadowRadius: 8,
  },
  payBtnDisabled: { opacity: 0.5 },
  payBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});
