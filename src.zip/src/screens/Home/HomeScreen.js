// ─────────────────────────────────────────────────────────────
//  HomeScreen.js  –  Dashboard / Home
// ─────────────────────────────────────────────────────────────
import React from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ScrollView,
  Alert, StatusBar,
} from 'react-native';
import { Feather as Icon } from '@expo/vector-icons';
import { useAuth } from '../../store/AuthContext';
import { logout } from '../../services/api';

const QuickAction = ({ icon, label, color, bg, onPress }) => (
  <TouchableOpacity style={[styles.actionCard, { backgroundColor: bg }]} onPress={onPress}>
    <View style={[styles.actionIcon, { backgroundColor: color + '20' }]}>
      <Icon name={icon} size={22} color={color} />
    </View>
    <Text style={[styles.actionLabel, { color }]}>{label}</Text>
  </TouchableOpacity>
);

export default function HomeScreen({ navigation }) {
  const { user, session, logoutUser } = useAuth();

  const handleLogout = async () => {
    Alert.alert('Logout', 'Are you sure you want to logout?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Logout', style: 'destructive', onPress: async () => {
          try { await logout(); } catch { }
          logoutUser();
        }
      },
    ]);
  };

  const greeting = () => {
    const h = new Date().getHours();
    if (h < 12) return 'Good Morning';
    if (h < 17) return 'Good Afternoon';
    return 'Good Evening';
  };

  return (
    <View style={styles.flex}>
      <StatusBar barStyle="dark-content" backgroundColor="#F0F4FF" />

      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>{greeting()},</Text>
          <Text style={styles.name}>{user?.name || 'Shopper'} 👋</Text>
        </View>
        <TouchableOpacity onPress={handleLogout} style={styles.logoutBtn}>
          <Icon name="log-out" size={18} color="#EF4444" />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>

        {/* Active Session Banner */}
        {session ? (
          <TouchableOpacity
            style={styles.sessionBanner}
            onPress={() => navigation.navigate('Cart')}
          >
            <View style={styles.sessionLeft}>
              <View style={styles.activeDot} />
              <View>
                <Text style={styles.sessionTitle}>Active Session</Text>
                <Text style={styles.sessionStore}>{session.storeName}</Text>
              </View>
            </View>
            <View style={styles.sessionRight}>
              <Text style={styles.sessionCta}>View Cart →</Text>
            </View>
          </TouchableOpacity>
        ) : (
          <View style={styles.welcomeCard}>
            <Text style={styles.welcomeEmoji}>🛒</Text>
            <Text style={styles.welcomeTitle}>Ready to shop smarter?</Text>
            <Text style={styles.welcomeText}>
              Select a store, scan products, and pay — all without waiting in queue.
            </Text>
          </View>
        )}

        {/* Quick Actions */}
        <Text style={styles.sectionTitle}>Quick Actions</Text>
        <View style={styles.actionsGrid}>
          <QuickAction
            icon="map-pin"
            label="Find Store"
            color="#2563EB"
            bg="#EFF6FF"
            onPress={() => navigation.navigate('StoreSelect')}
          />
          <QuickAction
            icon="shopping-cart"
            label="My Cart"
            color="#059669"
            bg="#ECFDF5"
            onPress={() => navigation.navigate('Cart')}
          />
          <QuickAction
            icon="clock"
            label="History"
            color="#D97706"
            bg="#FFFBEB"
            onPress={() => navigation.navigate('History')}
          />
          <QuickAction
            icon="credit-card"
            label="Pay Now"
            color="#7C3AED"
            bg="#F5F3FF"
            onPress={() => session
              ? navigation.navigate('Payment')
              : Alert.alert('No Session', 'Please start a shopping session first.')
            }
          />
        </View>

        {/* How it works */}
        <Text style={styles.sectionTitle}>How It Works</Text>
        <View style={styles.stepsCard}>
          {[
            { step: '1', icon: '📍', text: 'Select your store by QR or pincode' },
            { step: '2', icon: '📷', text: 'Scan products as you shop' },
            { step: '3', icon: '💳', text: 'Pay online or cash at counter' },
            { step: '4', icon: '🚪', text: 'Show QR at exit — walk out!' },
          ].map(({ step, icon, text }) => (
            <View key={step} style={styles.stepRow}>
              <View style={styles.stepNum}>
                <Text style={styles.stepNumText}>{step}</Text>
              </View>
              <Text style={styles.stepIcon}>{icon}</Text>
              <Text style={styles.stepText}>{text}</Text>
            </View>
          ))}
        </View>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: '#F0F4FF' },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: 20, paddingTop: 56, paddingBottom: 20,
    backgroundColor: '#F0F4FF',
  },
  greeting: { fontSize: 14, color: '#6B7280', fontWeight: '500' },
  name: { fontSize: 22, fontWeight: '800', color: '#111827' },
  logoutBtn: {
    width: 40, height: 40, borderRadius: 12, backgroundColor: '#FEF2F2',
    justifyContent: 'center', alignItems: 'center',
  },
  scroll: { paddingHorizontal: 20, paddingBottom: 32 },

  sessionBanner: {
    backgroundColor: '#2563EB', borderRadius: 16, padding: 16,
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    marginBottom: 24, shadowColor: '#2563EB', shadowOpacity: 0.3,
    shadowRadius: 12, elevation: 6,
  },
  sessionLeft: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  activeDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: '#4ADE80' },
  sessionTitle: { fontSize: 12, color: '#BFDBFE', fontWeight: '600' },
  sessionStore: { fontSize: 15, color: '#fff', fontWeight: '700' },
  sessionRight: {},
  sessionCta: { fontSize: 13, color: '#BFDBFE', fontWeight: '600' },

  welcomeCard: {
    backgroundColor: '#fff', borderRadius: 16, padding: 20,
    alignItems: 'center', marginBottom: 24,
    shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 8, elevation: 2,
  },
  welcomeEmoji: { fontSize: 40, marginBottom: 12 },
  welcomeTitle: { fontSize: 16, fontWeight: '700', color: '#111827', marginBottom: 6 },
  welcomeText: { fontSize: 13, color: '#6B7280', textAlign: 'center', lineHeight: 18 },

  sectionTitle: { fontSize: 16, fontWeight: '700', color: '#111827', marginBottom: 12 },

  actionsGrid: {
    flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 28,
  },
  actionCard: {
    width: '46%', borderRadius: 14, padding: 16, alignItems: 'center', gap: 10,
    shadowColor: '#000', shadowOpacity: 0.04, shadowRadius: 6, elevation: 2,
  },
  actionIcon: { width: 44, height: 44, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  actionLabel: { fontSize: 13, fontWeight: '700' },

  stepsCard: {
    backgroundColor: '#fff', borderRadius: 16, padding: 16,
    shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 8, elevation: 2,
    gap: 14,
  },
  stepRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  stepNum: {
    width: 26, height: 26, borderRadius: 8, backgroundColor: '#EFF6FF',
    justifyContent: 'center', alignItems: 'center',
  },
  stepNumText: { fontSize: 13, fontWeight: '800', color: '#2563EB' },
  stepIcon: { fontSize: 20 },
  stepText: { flex: 1, fontSize: 13, color: '#374151', lineHeight: 18 },
});
